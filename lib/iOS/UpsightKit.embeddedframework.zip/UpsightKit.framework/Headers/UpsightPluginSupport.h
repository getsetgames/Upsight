//
//  UpsightPluginSupport.h
//  UpsightKit
//
//  Created by Tolik Shevchenko on 7/13/15.
//  Copyright (c) 2015 Upsight. All rights reserved.
//

#import "Upsight.h"

@interface Upsight(PluginSupport)
+ (void)setPluginVersion:(NSString *)pluginVersion;
@end
